plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android {
 namespace = "lab.nfc"; compileSdk = 35
 defaultConfig { applicationId = "lab.nfc"; minSdk = 26; targetSdk = 35; versionCode = 5; versionName = "3.2-operational"; testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" }
 sourceSets.getByName("test").resources.srcDir("src/main/assets")
 testOptions { unitTests.isIncludeAndroidResources = true }
 buildFeatures { compose = true }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies {
 implementation("androidx.room:room-runtime:2.6.1")
 annotationProcessor("androidx.room:room-compiler:2.6.1")
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.activity:activity-compose:1.9.3")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
 implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
 androidTestImplementation("androidx.test.ext:junit:1.2.1")
 androidTestImplementation("androidx.test:runner:1.6.2")
 androidTestImplementation("androidx.test:core:1.6.1")
 testImplementation(platform("androidx.compose:compose-bom:2024.12.01"))
 testImplementation("androidx.compose.ui:ui-test-junit4")
 debugImplementation("androidx.compose.ui:ui-test-manifest")
 testImplementation("junit:junit:4.13.2")
 testImplementation("org.robolectric:robolectric:4.14.1")
 testImplementation("org.json:json:20240303")
}

tasks.withType<JavaCompile>().configureEach { options.compilerArgs.addAll(listOf("-Aroom.schemaLocation=$projectDir/schemas")) }
